package com.aria.assistant.ui

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aria.assistant.ui.theme.Black
import com.aria.assistant.ui.theme.Gold
import com.aria.assistant.ui.theme.GoldDark
import com.aria.assistant.ui.theme.GoldLight
import com.aria.assistant.ui.theme.SurfaceHigh
import com.aria.assistant.ui.theme.TextDim
import com.aria.assistant.ui.theme.TextLight

private val goldBrush = Brush.linearGradient(listOf(GoldLight, Gold, GoldDark))
private val chips = listOf(
    "Missed call dekhao", "Torch on", "Ajker khoroch koto", "Notification porho",
    "Ami kothay", "Note dekhao", "Routine morning"
)

@Composable
fun ChatScreen(vm: MainViewModel, onOpenSettings: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val ctx = LocalContext.current

    LaunchedEffect(vm.messages.size, vm.busy) {
        val last = vm.messages.size + (if (vm.busy) 1 else 0) - 1
        if (last >= 0) listState.animateScrollToItem(last)
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) vm.send(text)
    }

    fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, vm.store.voiceLang)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo…")
        try {
            speech.launch(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Voice recognition paini", Toast.LENGTH_LONG).show()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Black)
            .systemBarsPadding()
            .imePadding()
    ) {
        Header(onOpenSettings)
        HorizontalDivider(color = GoldDark.copy(alpha = 0.35f))

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.messages) { m -> Bubble(m) { vm.send(it) } }
            if (vm.busy) item { Bubble(ChatMsg("Aria chinta korchhe…", false)) {} }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chips) { c ->
                Text(
                    c,
                    color = Gold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .border(1.dp, GoldDark, RoundedCornerShape(50))
                        .clickable { vm.send(c) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        InputBar(
            input = input,
            onInput = { input = it },
            onSend = {
                if (input.isNotBlank()) {
                    vm.send(input)
                    input = ""
                }
            },
            onMic = { startVoice() }
        )
    }
}

@Composable
private fun Header(onOpenSettings: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(goldBrush),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Mic, null, tint = Black, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("ARIA", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 4.sp)
            Text("Personal assistant", color = TextDim, fontSize = 12.sp)
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Filled.Settings, "Settings", tint = Gold)
        }
    }
}

@Composable
private fun Bubble(msg: ChatMsg, onConfirm: (String) -> Unit) {
    val user = msg.fromUser
    val shape = if (user) RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp) else RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (user) Alignment.End else Alignment.Start
    ) {
        Box(
            Modifier
                .widthIn(max = 310.dp)
                .clip(shape)
                .then(
                    if (user) Modifier.background(Brush.linearGradient(listOf(GoldLight, Gold)))
                    else Modifier
                        .background(SurfaceHigh)
                        .border(1.dp, Gold.copy(alpha = 0.25f), shape)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                msg.text,
                color = if (user) Black else TextLight,
                fontSize = 15.sp,
                lineHeight = 21.sp
            )
        }
        if (msg.confirm) {
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Ha", filled = true) { onConfirm("ha") }
                PillButton("Na", filled = false) { onConfirm("na") }
            }
        }
    }
}

@Composable
fun PillButton(text: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = if (filled) Black else Gold,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(shape)
            .then(if (filled) Modifier.background(goldBrush) else Modifier.border(1.dp, Gold, shape))
            .clickable(onClick = onClick)
            .padding(horizontal = 26.dp, vertical = 9.dp)
    )
}

@Composable
private fun InputBar(input: String, onInput: (String) -> Unit, onSend: () -> Unit, onMic: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val shape = RoundedCornerShape(28.dp)
        Row(
            Modifier
                .weight(1f)
                .clip(shape)
                .background(SurfaceHigh)
                .border(1.dp, GoldDark.copy(alpha = 0.5f), shape),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = input,
                onValueChange = onInput,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Command likho… jemon: alarm 7:00 am", color = TextDim, fontSize = 14.sp) },
                maxLines = 4,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Gold,
                    focusedTextColor = TextLight,
                    unfocusedTextColor = TextLight
                )
            )
            IconButton(onClick = onSend) {
                Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Gold)
            }
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(goldBrush)
                .clickable(onClick = onMic),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Mic, "Voice", tint = Black, modifier = Modifier.size(26.dp))
        }
    }
}
