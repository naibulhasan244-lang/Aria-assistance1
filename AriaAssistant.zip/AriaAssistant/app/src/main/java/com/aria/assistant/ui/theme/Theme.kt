package com.aria.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Black = Color(0xFF0A0A0B)
val Surface1 = Color(0xFF141416)
val SurfaceHigh = Color(0xFF1E1E21)
val Gold = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF1D77A)
val GoldDark = Color(0xFF9C7A1E)
val TextLight = Color(0xFFEDE6D3)
val TextDim = Color(0xFF9A9486)

private val scheme = darkColorScheme(
    primary = Gold,
    onPrimary = Black,
    secondary = GoldLight,
    onSecondary = Black,
    background = Black,
    onBackground = TextLight,
    surface = Surface1,
    onSurface = TextLight,
    surfaceVariant = SurfaceHigh,
    onSurfaceVariant = TextDim,
    outline = GoldDark
)

private val typo = Typography().let { base ->
    base.copy(
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 3.sp),
        bodyLarge = base.bodyLarge.copy(fontSize = 15.sp, lineHeight = 22.sp)
    )
}

@Composable
fun AriaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typo, content = content)
}
