package com.aria.assistant.core

/**
 * Fast offline rule-based parser for Bangla / Banglish / English commands.
 * Returns null when it does not understand (then the Claude AI parser is tried, if an API key is set).
 */
object CommandParser {

    private val yes = setOf("ha", "haa", "han", "hya", "yes", "y", "ok", "okay", "ji", "confirm", "হ্যাঁ", "হ্যা", "হাঁ")
    private val no = setOf("na", "no", "nah", "cancel", "thak", "bad", "না")

    private val fillers = setOf(
        "koro", "kor", "dao", "dio", "den", "korun", "kore", "please", "plz", "pls",
        "amar", "amake", "ekta", "akta", "ke", "er", "set", "the", "a", "to", "me", "ta", "tar", "tomar"
    )

    private fun has(l: String, vararg w: String) = w.any { l.contains(it) }

    private fun hasWord(l: String, vararg w: String) =
        w.any { Regex("\\b" + Regex.escape(it) + "\\b").containsMatchIn(l) }

    private fun clean(s: String, extra: Set<String> = emptySet()): String =
        s.split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in fillers && it !in extra }
            .joinToString(" ")
            .trim(' ', ':', ',', '.', '-')

    /** Text after ':' if present, else the sentence with the trigger words removed. */
    private fun payload(t: String, vararg keywords: String): String {
        val i = t.indexOf(':')
        if (i >= 0) return t.substring(i + 1).trim()
        var r = t
        for (k in keywords) r = r.replace(Regex("(?i)" + Regex.escape(k)), " ")
        return r.replace(Regex("\\s+"), " ").trim()
    }

    private fun err(msg: String) = Cmd("error", mapOf("msg" to msg))

    fun parse(raw: String, now: Long = System.currentTimeMillis()): Cmd? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        val l = t.lowercase()

        // ---- confirmations ----
        if (l in yes) return Cmd("yes")
        if (l in no) return Cmd("no")
        if (Regex("^[1-9]$").matches(l)) return Cmd("choose", mapOf("n" to l))

        // ---- routines ----
        Regex("""routine\s+(?:save|banao|add|set)\s+(\S+)\s*:\s*(.+)""").find(l)?.let {
            return Cmd("routine_save", mapOf("name" to it.groupValues[1], "cmds" to it.groupValues[2]))
        }
        if (l.contains("routine")) {
            val name = clean(l, setOf("routine", "chalao", "run", "start", "shuru"))
            return Cmd("routine_run", mapOf("name" to name.ifEmpty { "morning" }))
        }

        // ---- notes (copy / show / add) ----
        val noteWord = has(l, "note", "নোট")
        if (noteWord && has(l, "copy", "kopi", "কপি")) {
            val n = Regex("""\d+""").find(l)?.value ?: "1"
            return Cmd("notes_copy", mapOf("n" to n))
        }
        if (noteWord && has(l, "dekhao", "show", "list", "koto", "sob", "দেখাও")) return Cmd("notes_show")
        if (l.startsWith("note")) {
            val body = t.replace(Regex("(?i)^notes?\\s*(koro|kor|lekho|likho)?\\s*[:\\-]?\\s*"), "").trim()
            if (body.isNotEmpty()) return Cmd("note", mapOf("text" to body))
        }

        // ---- copy text ----
        if (l.startsWith("copy")) {
            val body = t.substring(4).trim(' ', ':', '-')
            if (body.isNotEmpty()) return Cmd("copy", mapOf("text" to body))
        }

        // ---- expenses ----
        Regex("""(\d+(?:\.\d+)?)\s*(?:taka|tk|৳)\.?\s*(.*)""").find(l)?.let { m ->
            if (!has(l, "alarm", "remind", "timer")) {
                val label = clean(
                    m.groupValues[2],
                    setOf("khoroch", "kharcha", "hoyeche", "holo", "likho", "add", "jog", "expense")
                ).ifEmpty { "khoroch" }
                return Cmd("expense", mapOf("amount" to m.groupValues[1], "label" to label))
            }
        }
        if (has(l, "khoroch", "hisab", "expense", "kharcha") &&
            has(l, "dekhao", "koto", "total", "report", "show", "hisab")
        ) return Cmd("expense_report")

        // ---- AI text tools ----
        if (l.startsWith("translate") || has(l, "onubad", "অনুবাদ")) {
            return Cmd("translate", mapOf("text" to payload(t, "translate", "onubad", "koro")))
        }
        if (has(l, "summar", "songkhep", "সারসংক্ষেপ")) {
            return Cmd("summary", mapOf("text" to payload(t, "summarize", "summary", "songkhep", "koro")))
        }
        if (l.startsWith("reply") || has(l, "draft")) {
            return Cmd("draft", mapOf("text" to payload(t, "reply", "draft", "likho", "koro")))
        }

        // ---- alarm / timer / stopwatch / reminder / calendar ----
        if (has(l, "alarm", "অ্যালার্ম")) {
            val ts = TimeParser.parse(l, now, loose = true)
                ?: return err("Koto tay alarm? Jemon: alarm 7:00 am")
            return Cmd(
                "alarm",
                mapOf("hour" to ts.hour.toString(), "minute" to ts.minute.toString(), "millis" to ts.millis.toString())
            )
        }
        if (has(l, "stopwatch")) {
            val stop = has(l, "stop", "thamao", "bondho", "end")
            return Cmd("stopwatch", mapOf("action" to if (stop) "stop" else "start"))
        }
        if (has(l, "timer")) {
            val m = Regex("""(\d+)\s*(sec|second|minute|minit|min|ghonta|ghanta|hour|hr)""").find(l)
                ?: return err("Koto shomoyer timer? Jemon: timer 5 minute")
            val n = m.groupValues[1].toInt()
            val u = m.groupValues[2]
            val secs = when {
                u.startsWith("sec") -> n
                u.startsWith("min") -> n * 60
                else -> n * 3600
            }
            return Cmd("timer", mapOf("seconds" to secs.toString()))
        }
        if (has(l, "remind", "mone koriye", "মনে করিয়ে")) {
            val ts = TimeParser.parse(l, now, loose = false)
                ?: return err("Kokhon mone koriye dibo? Jemon: 10 minute por pani khete mone koriye dio")
            val text = clean(
                l.replace(ts.matched, " "),
                setOf(
                    "reminder", "remind", "mone", "koriye", "kal", "kalke", "ajke", "aj", "por", "pore",
                    "shokal", "dupur", "bikal", "shondha", "rat", "am", "pm", "tay", "te"
                )
            ).ifEmpty { "Reminder" }
            return Cmd("reminder", mapOf("text" to text, "millis" to ts.millis.toString()))
        }
        if (has(l, "meeting", "event", "calendar")) {
            val ts = TimeParser.parse(l, now, loose = true)
                ?: return err("Kokhon? Jemon: shukrobar 5 tay meeting")
            val extra = setOf(
                "calendar", "event", "add", "kal", "kalke", "ajke", "aj", "tay", "te",
                "am", "pm", "shokal", "dupur", "bikal", "shondha", "rat", "ache", "rakho", "likhe", "create"
            ) + TimeParser.weekdays.keys
            val title = clean(l.replace(ts.matched, " "), extra)
                .ifEmpty { "Event" }
                .replaceFirstChar { it.uppercase() }
            return Cmd("event", mapOf("title" to title, "millis" to ts.millis.toString()))
        }
        if (has(l, "likhe rakho", "note koro")) {
            val body = t.replace(Regex("(?i)\\s*(likhe rakho|note koro)\\s*"), " ").trim()
            if (body.isNotEmpty()) return Cmd("note", mapOf("text" to body))
        }

        // ---- calls / contacts / messaging ----
        if (has(l, "missed", "miss call", "miscall")) return Cmd("missed")

        val msgWord = hasWord(l, "sms", "whatsapp", "message", "msg", "text")
        if ((msgWord || has(l, "likho", "pathao", "pathan")) && l.contains(" ke ")) {
            val idx = l.indexOf(" ke ")
            val name = clean(
                l.substring(0, idx),
                setOf("sms", "whatsapp", "message", "msg", "text", "send", "pathao", "pathan", "likho")
            )
            val body = t.substring(idx + 4)
                .replace(
                    Regex("(?i)^\\s*(whatsapp|sms|message|msg|text)?\\s*(pathao|pathan|pathiye\\s*dao|likho|likhe\\s*dao|bolo|bol)?\\s*[:\\-]?\\s*"),
                    ""
                ).trim()
            if (name.isEmpty()) return err("Kar kache pathabo?")
            if (body.isEmpty()) return err("Ki likhbo? Jemon: Rahim ke likho ami aschi")
            val type = if (hasWord(l, "sms")) "sms" else "whatsapp"
            return Cmd(type, mapOf("name" to name, "body" to body))
        }

        if (hasWord(l, "call", "phone", "fon", "dial") || has(l, "কল", "ফোন")) {
            val name = clean(l, setOf("call", "phone", "fon", "dial", "কল", "ফোন", "lagao", "lagiye", "korte", "chai"))
            if (name.isEmpty()) return err("Kake call korbo? Jemon: Rahim ke call koro")
            return Cmd("call", mapOf("name" to name))
        }
        if (has(l, "number", "nombor", "নাম্বার")) {
            val name = clean(
                l,
                setOf("number", "nombor", "নাম্বার", "ber", "dekhao", "koto", "ki", "khuje", "bol", "bolo", "ta")
            )
            if (name.isEmpty()) return err("Kar number? Jemon: Rahim er number ber koro")
            return Cmd("number", mapOf("name" to name))
        }

        // ---- open app ----
        if (hasWord(l, "open", "khol", "kholo", "chalu") || has(l, "খোল")) {
            val app = clean(l, setOf("open", "khol", "kholo", "khulo", "chalu", "app", "খোল"))
            if (app.isNotEmpty()) return Cmd("open", mapOf("app" to app))
        }

        // ---- device controls ----
        val off = has(l, "off", "bondho", "bandho", "nibao", "nivao", "বন্ধ")
        if (has(l, "torch", "flash", "tarch", "টর্চ")) return Cmd("torch", mapOf("on" to (!off).toString()))
        if (has(l, "wifi", "wi-fi")) return Cmd("wifi")
        if (has(l, "bluetooth")) return Cmd("bluetooth")
        if (has(l, "volume")) {
            val n = Regex("""\d+""").find(l)?.value
            val mode = when {
                n != null -> "set"
                has(l, "mute") -> "mute"
                has(l, "down", "komao", "kom", "low") -> "down"
                else -> "up"
            }
            return Cmd("volume", mapOf("mode" to mode, "n" to (n ?: "")))
        }
        if (has(l, "brightness", "brightnes")) {
            val n = Regex("""\d+""").find(l)?.value
            val mode = if (has(l, "down", "komao", "kom", "low")) "down" else "up"
            return Cmd("brightness", mapOf("mode" to mode, "n" to (n ?: "")))
        }
        if (has(l, "silent", "dnd", "do not disturb")) {
            val on = !(off || has(l, "normal"))
            return Cmd("dnd", mapOf("on" to on.toString()))
        }

        // ---- info ----
        if (has(l, "notification", "noti")) return Cmd("notifs")
        if (has(l, "location", "kothay")) {
            val share = has(l, "share", "pathao", "pathan", "send")
            return Cmd("location", mapOf("share" to share.toString()))
        }

        return null
    }
}
