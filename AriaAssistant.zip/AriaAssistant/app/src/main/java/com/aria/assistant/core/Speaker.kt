package com.aria.assistant.core

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Text-to-speech wrapper (singleton so it survives short-lived activities). */
class Speaker private constructor(ctx: Context) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(ctx, this)
    private var ready = false

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
    }

    fun speak(text: String, lang: String) {
        if (!ready) return
        val loc = Locale.forLanguageTag(lang)
        tts.language = if (tts.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) loc else Locale.US
        tts.speak(text.take(500), TextToSpeech.QUEUE_FLUSH, null, "aria")
    }

    companion object {
        @Volatile private var inst: Speaker? = null
        fun get(ctx: Context): Speaker = inst ?: synchronized(this) {
            inst ?: Speaker(ctx.applicationContext).also { inst = it }
        }
    }
}
