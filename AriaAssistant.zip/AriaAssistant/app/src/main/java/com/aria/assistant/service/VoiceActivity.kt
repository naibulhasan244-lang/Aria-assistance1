package com.aria.assistant.service

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.aria.assistant.core.Assistant
import com.aria.assistant.core.Reply
import com.aria.assistant.core.Speaker
import com.aria.assistant.core.Store
import kotlinx.coroutines.launch

/** Invisible activity opened by the floating mic: listens, runs the command, speaks the reply, closes. */
class VoiceActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == RESULT_OK && !text.isNullOrBlank()) process(text) else finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, store.voiceLang)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo…")
        try {
            launcher.launch(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Voice recognition paini", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun process(text: String) {
        lifecycleScope.launch {
            val reply = try {
                Assistant.get(this@VoiceActivity).handle(text)
            } catch (e: Exception) {
                Reply("Error: ${e.message ?: e.javaClass.simpleName}")
            }
            Toast.makeText(this@VoiceActivity, reply.text.take(300), Toast.LENGTH_LONG).show()
            Speaker.get(this@VoiceActivity).speak(reply.text, Store(this@VoiceActivity).voiceLang)
            finish()
        }
    }
}
