package com.aria.assistant.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aria.assistant.core.Assistant
import com.aria.assistant.core.Reply
import com.aria.assistant.core.Speaker
import com.aria.assistant.core.Store
import kotlinx.coroutines.launch

data class ChatMsg(val text: String, val fromUser: Boolean, val confirm: Boolean = false)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    private val assistant = Assistant.get(app)

    val messages = mutableStateListOf(
        ChatMsg(
            "Assalamu alaikum! Ami Aria 👋\nBolo ki korte hobe — call, alarm, reminder, note, khoroch, torch, WhatsApp… sob.",
            fromUser = false
        )
    )

    var busy by mutableStateOf(false)
        private set

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        // old confirm buttons are no longer valid once the user answers
        for (i in messages.indices) if (messages[i].confirm) messages[i] = messages[i].copy(confirm = false)
        messages.add(ChatMsg(t, fromUser = true))
        busy = true
        viewModelScope.launch {
            val r = try {
                assistant.handle(t)
            } catch (e: Exception) {
                Reply("Error: ${e.message ?: e.javaClass.simpleName}")
            }
            messages.add(ChatMsg(r.text, fromUser = false, confirm = r.confirm))
            busy = false
            if (store.speakReplies) Speaker.get(getApplication<Application>()).speak(r.text, store.voiceLang)
        }
    }
}
