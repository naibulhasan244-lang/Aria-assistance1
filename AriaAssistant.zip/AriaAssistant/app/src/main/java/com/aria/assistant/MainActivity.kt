package com.aria.assistant

import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aria.assistant.core.Store
import com.aria.assistant.service.FloatingMicService
import com.aria.assistant.ui.ChatScreen
import com.aria.assistant.ui.MainViewModel
import com.aria.assistant.ui.SettingsScreen
import com.aria.assistant.ui.theme.AriaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        val store = Store(this)
        if (store.floatingMic && Settings.canDrawOverlays(this)) FloatingMicService.start(this)

        setContent {
            AriaTheme { Root(store) }
        }
    }
}

@Composable
private fun Root(store: Store) {
    val ctx = LocalContext.current
    val vm: MainViewModel = viewModel()
    var showSettings by remember { mutableStateOf(false) }

    if (showSettings) {
        SettingsScreen(
            store = store,
            onBack = { showSettings = false },
            onFloatingChanged = { on ->
                if (on) FloatingMicService.start(ctx) else FloatingMicService.stop(ctx)
            }
        )
    } else {
        ChatScreen(vm = vm, onOpenSettings = { showSettings = true })
    }
}
