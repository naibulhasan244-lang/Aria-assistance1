package com.aria.assistant.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aria.assistant.core.Store
import com.aria.assistant.ui.theme.Black
import com.aria.assistant.ui.theme.Gold
import com.aria.assistant.ui.theme.GoldDark
import com.aria.assistant.ui.theme.SurfaceHigh
import com.aria.assistant.ui.theme.TextDim
import com.aria.assistant.ui.theme.TextLight

@Composable
fun SettingsScreen(store: Store, onBack: () -> Unit, onFloatingChanged: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(store.apiKey) }
    var lang by remember { mutableStateOf(store.voiceLang) }
    var speak by remember { mutableStateOf(store.speakReplies) }
    var floating by remember { mutableStateOf(store.floatingMic) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    BackHandler(onBack = onBack)

    Column(
        Modifier
            .fillMaxSize()
            .background(Black)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Gold) }
            Text("Settings", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }

        Section("Claude AI (optional, kintu khub dorkari)")
        Text(
            "API key dile Aria je kono kotha bujhbe, translate/summary/reply likhte parbe. Key shudhu ei phone-e thake.",
            color = TextDim, fontSize = 13.sp
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = key,
            onValueChange = { key = it; store.apiKey = it },
            label = { Text("Claude API key (sk-ant-…)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Gold, unfocusedBorderColor = GoldDark, cursorColor = Gold,
                focusedTextColor = TextLight, unfocusedTextColor = TextLight,
                focusedLabelColor = Gold, unfocusedLabelColor = TextDim
            )
        )

        Section("Voice")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LangChip("বাংলা", lang == "bn-BD") { lang = "bn-BD"; store.voiceLang = lang }
            LangChip("English", lang == "en-US") { lang = "en-US"; store.voiceLang = lang }
        }
        ToggleRow("Reply joreo bolbe", "Aria uttor shonabe", speak) { speak = it; store.speakReplies = it }
        ToggleRow("Floating mic", "Shob app-er upor gold mic button", floating) { on ->
            if (on && !Settings.canDrawOverlays(ctx)) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } else {
                floating = on
                store.floatingMic = on
                onFloatingChanged(on)
            }
        }
        Text(
            "Floating mic on korte age 'Display over other apps' allow koro, tarpor ekhane abar on koro.",
            color = TextDim, fontSize = 12.sp
        )

        Section("Permissions")
        GoldButton("Sob permission dao (Contacts, Call, SMS, Call log, Location, Notification)") {
            val list = mutableListOf(
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(list.toTypedArray())
        }
        GoldButton("Notification access (notification porhar jonno)") {
            open(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        GoldButton("Do Not Disturb access (silent mode)") {
            open(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        GoldButton("Modify system settings (brightness)") {
            open(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
        }
        if (Build.VERSION.SDK_INT >= 31) {
            GoldButton("Exact alarms (thik shomoy reminder)") {
                open(ctx, Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

private fun open(ctx: Context, i: Intent) {
    try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(22.dp))
    Text(title.uppercase(), color = Gold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun LangChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold,
            selectedLabelColor = Black,
            containerColor = SurfaceHigh,
            labelColor = TextLight
        )
    )
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextLight, fontSize = 15.sp)
            Text(sub, color = TextDim, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Black,
                checkedTrackColor = Gold,
                uncheckedThumbColor = TextDim,
                uncheckedTrackColor = SurfaceHigh
            )
        )
    }
}

@Composable
private fun GoldButton(text: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(1.dp, GoldDark, RoundedCornerShape(50)),
        shape = RoundedCornerShape(50)
    ) {
        Text(text, color = Gold, fontSize = 13.sp)
    }
}
