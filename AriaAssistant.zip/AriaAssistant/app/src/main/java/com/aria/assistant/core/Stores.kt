package com.aria.assistant.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Note(val id: Long, val text: String, val time: Long)
data class Expense(val amount: Double, val label: String, val time: Long)

/** Simple local storage (SharedPreferences + JSON). */
class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("aria_store", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    /** "bn-BD" or "en-US" */
    var voiceLang: String
        get() = sp.getString("voice_lang", "bn-BD") ?: "bn-BD"
        set(v) = sp.edit().putString("voice_lang", v).apply()

    var speakReplies: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) = sp.edit().putBoolean("speak", v).apply()

    var floatingMic: Boolean
        get() = sp.getBoolean("floating", false)
        set(v) = sp.edit().putBoolean("floating", v).apply()

    // ---------- Notes ----------
    fun notes(): List<Note> {
        val arr = JSONArray(sp.getString("notes", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Note(o.getLong("id"), o.getString("text"), o.getLong("time"))
        }
    }

    fun addNote(text: String) {
        val now = System.currentTimeMillis()
        val list = notes().toMutableList()
        list.add(0, Note(now, text, now))
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time)) }
        sp.edit().putString("notes", arr.toString()).apply()
    }

    // ---------- Expenses ----------
    fun expenses(): List<Expense> {
        val arr = JSONArray(sp.getString("expenses", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Expense(o.getDouble("amount"), o.getString("label"), o.getLong("time"))
        }
    }

    fun addExpense(amount: Double, label: String) {
        val list = expenses().toMutableList()
        list.add(0, Expense(amount, label, System.currentTimeMillis()))
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("amount", it.amount).put("label", it.label).put("time", it.time)) }
        sp.edit().putString("expenses", arr.toString()).apply()
    }

    // ---------- Routines ----------
    fun routines(): Map<String, String> {
        val o = JSONObject(sp.getString("routines", null) ?: DEFAULT_ROUTINES)
        val map = mutableMapOf<String, String>()
        o.keys().forEach { map[it] = o.getString(it) }
        return map
    }

    fun saveRoutine(name: String, cmds: String) {
        val o = JSONObject(sp.getString("routines", null) ?: DEFAULT_ROUTINES)
        o.put(name.lowercase(), cmds)
        sp.edit().putString("routines", o.toString()).apply()
    }

    companion object {
        private const val DEFAULT_ROUTINES = """{"morning":"volume 50; missed call; notification porho"}"""
    }
}
