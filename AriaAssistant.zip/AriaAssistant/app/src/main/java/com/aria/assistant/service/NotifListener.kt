package com.aria.assistant.service

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import java.util.Collections

/** Keeps the latest notifications in memory so Aria can read them out ("notification porho"). */
class NotifListener : NotificationListenerService() {

    data class Item(val app: String, val title: String, val text: String, val time: Long)

    companion object {
        val items: MutableList<Item> = Collections.synchronizedList(mutableListOf())

        fun enabled(ctx: Context): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }

    override fun onListenerConnected() {
        try {
            activeNotifications?.forEach { add(it) }
        } catch (_: Exception) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        add(sbn)
    }

    private fun add(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isEmpty() && text.isEmpty()) return
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        items.add(0, Item(label, title, text, sbn.postTime))
        while (items.size > 30) items.removeAt(items.size - 1)
    }
}
