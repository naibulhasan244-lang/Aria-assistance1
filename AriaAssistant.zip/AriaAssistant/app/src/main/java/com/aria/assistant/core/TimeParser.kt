package com.aria.assistant.core

import java.util.Calendar

data class TimeSpec(val millis: Long, val hour: Int, val minute: Int, val matched: String)

/** Understands things like: "7:00 am", "kal shokal 7 tay", "shukrobar 5 tay", "10 minute por". */
object TimeParser {

    val weekdays: Map<String, Int> = mapOf(
        "robibar" to Calendar.SUNDAY, "rabibar" to Calendar.SUNDAY, "sunday" to Calendar.SUNDAY,
        "shombar" to Calendar.MONDAY, "sombar" to Calendar.MONDAY, "monday" to Calendar.MONDAY,
        "mongolbar" to Calendar.TUESDAY, "mongalbar" to Calendar.TUESDAY, "tuesday" to Calendar.TUESDAY,
        "budhbar" to Calendar.WEDNESDAY, "wednesday" to Calendar.WEDNESDAY,
        "brihoshpotibar" to Calendar.THURSDAY, "brihospotibar" to Calendar.THURSDAY,
        "brihaspatibar" to Calendar.THURSDAY, "thursday" to Calendar.THURSDAY,
        "shukrobar" to Calendar.FRIDAY, "sukrobar" to Calendar.FRIDAY, "friday" to Calendar.FRIDAY,
        "shonibar" to Calendar.SATURDAY, "shanibar" to Calendar.SATURDAY, "saturday" to Calendar.SATURDAY
    )

    private val pmWords = listOf(
        "dupur", "dupure", "bikal", "bikele", "shondha", "shondhay", "sondha",
        "rat", "rate", "raat", "afternoon", "evening", "night", "noon"
    )
    private val amWords = listOf("shokal", "shokale", "sokal", "bhor", "morning")

    private fun word(l: String, w: String) = Regex("\\b$w\\b").containsMatchIn(l)

    fun parse(l: String, now: Long = System.currentTimeMillis(), loose: Boolean = false): TimeSpec? {
        relative(l, now)?.let { return it }

        val rx = Regex("""(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm|tay|ta|te)?(?![\w])""")
        val all = rx.findAll(l).filter {
            it.groupValues[1].toInt() <= 24 && it.groupValues[2].ifEmpty { "0" }.toInt() < 60
        }.toList()
        val strict = all.firstOrNull { it.groupValues[2].isNotEmpty() || it.groupValues[3].isNotEmpty() }
        val pick = strict ?: (if (loose) all.firstOrNull() else null) ?: return null

        val h = pick.groupValues[1].toInt()
        val mm = pick.groupValues[2].ifEmpty { "0" }.toInt()
        val marker = pick.groupValues[3]
        val pm = marker == "pm" || pmWords.any { word(l, it) }
        val am = marker == "am" || amWords.any { word(l, it) }
        val wd = weekdays.entries.firstOrNull { word(l, it.key) }?.value
        val tomorrow = Regex("\\bkal(ke)?\\b").containsMatchIn(l)
        val todayDow = Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.DAY_OF_WEEK)
        val dayOffset: Int? = when {
            wd != null -> (wd - todayDow + 7) % 7
            tomorrow -> 1
            else -> null
        }

        fun at(h24: Int, off: Int): Long = Calendar.getInstance().apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, off)
            set(Calendar.HOUR_OF_DAY, h24)
            set(Calendar.MINUTE, mm)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val cands = when {
            h > 12 || h == 0 -> listOf(h % 24)
            pm -> listOf(if (h == 12) 12 else h + 12)
            am -> listOf(if (h == 12) 0 else h)
            else -> listOf(h % 12, h % 12 + 12)
        }

        val millis: Long = if (dayOffset != null) {
            val h24 = if (cands.size == 2) (if (h in 5..11) cands[0] else cands[1]) else cands[0]
            var t = at(h24, dayOffset)
            if (t <= now) t = at(h24, dayOffset + (if (wd != null) 7 else 1))
            t
        } else {
            cands.map { c ->
                val t = at(c, 0)
                if (t <= now) at(c, 1) else t
            }.min()
        }

        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return TimeSpec(millis, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), pick.value)
    }

    private fun relative(l: String, now: Long): TimeSpec? {
        val m = Regex("""(\d+)\s*(minute|minit|min|ghonta|ghanta|hour|hr)\w*\s*(?:por|pore|later)""")
            .find(l) ?: return null
        val n = m.groupValues[1].toLong()
        val ms = if (m.groupValues[2].startsWith("min")) n * 60_000L else n * 3_600_000L
        val t = now + ms
        val cal = Calendar.getInstance().apply { timeInMillis = t }
        return TimeSpec(t, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), m.value)
    }
}
