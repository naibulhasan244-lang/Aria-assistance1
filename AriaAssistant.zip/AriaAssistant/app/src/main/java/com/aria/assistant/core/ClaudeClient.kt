package com.aria.assistant.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Minimal Claude API client (no extra libraries needed). */
object ClaudeClient {
    // Fast + cheap model. Change here if you want a smarter one (e.g. "claude-sonnet-5-5").
    const val MODEL = "claude-haiku-5-5"

    suspend fun ask(apiKey: String, system: String, user: String, maxTokens: Int = 700): String =
        withContext(Dispatchers.IO) {
            val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("content-type", "application/json")
                setRequestProperty("x-api-key", apiKey)
                setRequestProperty("anthropic-version", "2023-06-01")
            }
            val body = JSONObject()
                .put("model", MODEL)
                .put("max_tokens", maxTokens)
                .put("system", system)
                .put(
                    "messages",
                    JSONArray().put(JSONObject().put("role", "user").put("content", user))
                )
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val stream = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?: throw RuntimeException("Claude API: no response ($code)")
            val txt = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }
                    .getOrDefault(txt.take(150))
                throw RuntimeException("Claude API error $code: $msg")
            }
            JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text").trim()
        }
}
