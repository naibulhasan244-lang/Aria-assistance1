package com.aria.assistant.core

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.aria.assistant.service.NotifListener
import com.aria.assistant.service.ReminderReceiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Cmd(val type: String, val a: Map<String, String> = emptyMap())
data class Reply(val text: String, val confirm: Boolean = false)

/**
 * The brain: understands a command (rules first, Claude AI as fallback) and performs it on the phone.
 * One shared instance, so a pending "Ha/Na" confirmation survives between the chat screen and the floating mic.
 */
class Assistant private constructor(private val ctx: Context) {

    companion object {
        @Volatile private var inst: Assistant? = null
        fun get(c: Context): Assistant = inst ?: synchronized(this) {
            inst ?: Assistant(c.applicationContext).also { inst = it }
        }
    }

    private val store = Store(ctx)

    private var pending: Cmd? = null
    private var choices: List<Pair<String, String>> = emptyList()
    private var choiceAction = ""
    private var choiceBody = ""
    private var stopwatchStart = 0L
    private var torchId: String? = null

    // =====================================================================
    //  Entry point
    // =====================================================================
    suspend fun handle(input: String): Reply {
        val text = input.trim()
        if (text.isEmpty()) return Reply("Kichu likho ba bolo.")

        var cmd = CommandParser.parse(text)
        if (cmd == null) {
            if (store.apiKey.isBlank()) return Reply(HELP)
            cmd = aiIntent(text) ?: return Reply(HELP)
        }
        return execute(cmd)
    }

    private val HELP = """Bujhte parlam na. Ei rokom bolte paro:
• Rahim ke call koro
• Rahim er number ber koro
• whatsapp open koro
• alarm 7:00 am
• 10 minute por pani khete mone koriye dio
• Rahim ke likho ami aschi
• torch on / volume 60 / silent mode
• 500 taka bazar  |  ajker khoroch koto
• note: kal bank jabo  |  prothom 5 ta note copy koro
• missed call dekhao  |  notification porho

Je kono kotha bujhte Settings e Claude API key dao."""

    // =====================================================================
    //  Executor
    // =====================================================================
    private suspend fun execute(cmd: Cmd): Reply {
        return when (cmd.type) {
            "error" -> Reply(cmd.a["msg"] ?: "Bujhte parlam na.")
            "yes" -> {
                val p = pending
                if (p == null) Reply("Confirm korar moto kichu nai.") else {
                    pending = null
                    doConfirmed(p)
                }
            }
            "no" -> {
                pending = null
                choices = emptyList()
                Reply("Thik ache, bad dilam.")
            }
            "choose" -> {
                val i = (cmd.a["n"]?.toIntOrNull() ?: 0) - 1
                if (choices.isEmpty() || i !in choices.indices) Reply("Ekhon choose korar moto kichu nai.") else {
                    val c = choices[i]
                    choices = emptyList()
                    proceed(choiceAction, c.first, c.second, choiceBody)
                }
            }

            "call", "sms", "whatsapp", "number" ->
                contactFlow(cmd.type, cmd.a["name"].orEmpty(), cmd.a["body"].orEmpty())

            "open" -> openApp(cmd.a["app"].orEmpty())
            "copy" -> {
                copyToClipboard(cmd.a["text"].orEmpty())
                Reply("Copy korlam.")
            }
            "notes_copy" -> notesCopy(cmd.a["n"]?.toIntOrNull() ?: 1)
            "notes_show" -> {
                val list = store.notes().take(10)
                if (list.isEmpty()) Reply("Kono note nai.")
                else Reply(list.mapIndexed { i, n -> "${i + 1}. ${n.text}" }.joinToString("\n"))
            }
            "note" -> {
                store.addNote(cmd.a["text"].orEmpty())
                Reply("Note save korlam ✓")
            }

            "alarm" -> setAlarm(cmd)
            "reminder" -> setReminder(cmd)
            "timer" -> {
                val s = cmd.a["seconds"]?.toIntOrNull() ?: return Reply("Timer koto second?")
                val ok = launch(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, s)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, "Aria timer")
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
                if (ok) Reply("Timer set: ${durationText(s)}") else Reply("Clock app paini.")
            }
            "stopwatch" -> {
                if (cmd.a["action"] == "stop") {
                    if (stopwatchStart == 0L) Reply("Stopwatch cholchhe na.") else {
                        val sec = (SystemClock.elapsedRealtime() - stopwatchStart) / 1000
                        stopwatchStart = 0L
                        Reply("Stopwatch thamlo: ${durationText(sec.toInt())}")
                    }
                } else {
                    stopwatchStart = SystemClock.elapsedRealtime()
                    Reply("Stopwatch shuru ✓ (thamate bolo: stopwatch stop)")
                }
            }
            "event" -> addEvent(cmd)

            "torch" -> torch(cmd.a["on"] != "false")
            "wifi" -> {
                launch(
                    if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                    else Intent(Settings.ACTION_WIFI_SETTINGS)
                )
                Reply("WiFi panel khule dilam. Android 10+ e app theke sorasori on/off kora jay na, panel theke ek tap e hobe.")
            }
            "bluetooth" -> {
                launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                Reply("Bluetooth settings khule dilam. Android 10+ e sorasori on/off kora jay na.")
            }
            "volume" -> volume(cmd)
            "brightness" -> brightness(cmd)
            "dnd" -> dnd(cmd.a["on"] != "false")

            "notifs" -> readNotifications()
            "missed" -> missedCalls()
            "location" -> location(cmd.a["share"] == "true")

            "translate", "summary", "draft" -> aiText(cmd)
            "chat" -> Reply(cmd.a["answer"] ?: "Bujhte parlam na.")

            "expense" -> {
                val amt = cmd.a["amount"]?.toDoubleOrNull() ?: return Reply("Koto taka?")
                val label = cmd.a["label"] ?: "khoroch"
                store.addExpense(amt, label)
                val today = expensesSince(startOfDay())
                Reply("Khoroch jog holo: ${money(amt)} taka ($label)\nAjker total: ${money(today)} taka")
            }
            "expense_report" -> expenseReport()

            "routine_save" -> {
                val name = cmd.a["name"].orEmpty()
                store.saveRoutine(name, cmd.a["cmds"].orEmpty())
                Reply("Routine '$name' save hoyeche. Chalate bolo: routine $name")
            }
            "routine_run" -> runRoutine(cmd.a["name"].orEmpty().lowercase())

            else -> Reply(HELP)
        }
    }

    // =====================================================================
    //  Contacts / call / sms / whatsapp
    // =====================================================================
    private suspend fun contactFlow(action: String, name: String, body: String): Reply {
        if (name.isBlank()) return Reply("Kar naam? Jemon: Rahim ke call koro")
        val found = withContext(Dispatchers.IO) { findContacts(name) } ?: return needPerm("Contacts")
        if (found.isEmpty()) return Reply("\"$name\" naam e kono contact paini.")

        val grouped = found.distinctBy { it.first }
        grouped.firstOrNull { it.first.equals(name, ignoreCase = true) }?.let {
            return proceed(action, it.first, it.second, body)
        }
        if (grouped.size > 1) {
            choices = grouped.take(5)
            choiceAction = action
            choiceBody = body
            val list = choices.mapIndexed { i, c -> "${i + 1}. ${c.first} (${c.second})" }.joinToString("\n")
            return Reply("Kon ta?\n$list\nNumber bolo (1, 2...)")
        }
        return proceed(action, grouped[0].first, grouped[0].second, body)
    }

    private fun proceed(action: String, name: String, number: String, body: String): Reply = when (action) {
        "call" -> {
            pending = Cmd("do_call", mapOf("name" to name, "number" to number))
            Reply("$name ($number) ke call dibo?", confirm = true)
        }
        "sms" -> {
            if (body.isBlank()) Reply("Ki likhbo?") else {
                pending = Cmd("do_sms", mapOf("name" to name, "number" to number, "body" to body))
                Reply("$name ($number) ke SMS pathabo:\n\"$body\"\n\nPathabo?", confirm = true)
            }
        }
        "number" -> {
            copyToClipboard(number)
            Reply("$name: $number\n(Clipboard-e copy kora hoyeche)")
        }
        else -> whatsapp(name, number, body)
    }

    private fun doConfirmed(p: Cmd): Reply {
        val number = p.a["number"].orEmpty()
        val name = p.a["name"].orEmpty()
        return when (p.type) {
            "do_call" -> {
                val uri = Uri.fromParts("tel", number, null)
                if (has(Manifest.permission.CALL_PHONE)) {
                    launch(Intent(Intent.ACTION_CALL, uri))
                    Reply("$name ke call korchhi…")
                } else {
                    launch(Intent(Intent.ACTION_DIAL, uri))
                    Reply("Call permission nai, tai dialer khule dilam. Call button chepe dao.")
                }
            }
            "do_sms" -> {
                if (!has(Manifest.permission.SEND_SMS)) return needPerm("SMS")
                try {
                    val sms = smsManager()
                    sms.sendMultipartTextMessage(number, null, sms.divideMessage(p.a["body"].orEmpty()), null, null)
                    Reply("SMS pathiye dilam ✓ ($name)")
                } catch (e: Exception) {
                    Reply("SMS pathate parlam na: ${e.message}")
                }
            }
            else -> Reply("Kichu korar nai.")
        }
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun whatsapp(name: String, number: String, body: String): Reply {
        val digits = number.filter { it.isDigit() }
        val intl = when {
            number.trim().startsWith("+") -> digits
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") -> "880" + digits.drop(1) // Bangladesh default
            else -> digits
        }
        val uri = Uri.parse("https://wa.me/$intl?text=${Uri.encode(body)}")
        return if (launch(Intent(Intent.ACTION_VIEW, uri))) Reply("WhatsApp-e $name er chat khulechhe, message ready. Send chepe dao ✓")
        else Reply("WhatsApp khulte parlam na.")
    }

    private fun findContacts(q: String): List<Pair<String, String>>? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val out = mutableListOf<Pair<String, String>>()
        val p = ContactsContract.CommonDataKinds.Phone
        ctx.contentResolver.query(
            p.CONTENT_URI,
            arrayOf(p.DISPLAY_NAME, p.NUMBER),
            "${p.DISPLAY_NAME} LIKE ?",
            arrayOf("%$q%"),
            "${p.DISPLAY_NAME} ASC"
        )?.use { c ->
            while (c.moveToNext()) out.add(c.getString(0) to c.getString(1))
        }
        return out
    }

    // =====================================================================
    //  Apps, notes, clipboard
    // =====================================================================
    private val aliases = mapOf(
        "fb" to "facebook", "insta" to "instagram", "yt" to "youtube",
        "gallery" to "photos", "msg" to "messages", "wa" to "whatsapp"
    )

    private fun openApp(nameRaw: String): Reply {
        val name = (aliases[nameRaw.lowercase()] ?: nameRaw).lowercase()
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val hit = apps.firstOrNull { it.first.lowercase() == name }
            ?: apps.firstOrNull { it.first.lowercase().contains(name) }
            ?: return Reply("\"$nameRaw\" naam er app paini.")
        val launchIntent = pm.getLaunchIntentForPackage(hit.second) ?: return Reply("${hit.first} khulte parlam na.")
        return if (launch(launchIntent)) Reply("${hit.first} khulchhi…") else Reply("${hit.first} khulte parlam na.")
    }

    private suspend fun notesCopy(nRaw: Int): Reply {
        val n = nRaw.coerceIn(1, 20)
        val list = store.notes().take(n)
        if (list.isEmpty()) return Reply("Kono note nai. Age note save koro: note: ...")
        withContext(Dispatchers.Main) {
            // oldest of the selected first, so the newest note ends up at the top of Gboard's clipboard history
            for (note in list.reversed()) {
                copyToClipboard(note.text)
                delay(900)
            }
        }
        return Reply("${list.size} ta note ek ek kore copy korlam ✓\nGboard keyboard-er clipboard icon e dekho (dorkari gulo pin kore rakho).")
    }

    private fun copyToClipboard(text: String) {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("aria", text))
    }

    private fun readClipboard(): String = try {
        ctx.getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
    } catch (e: Exception) {
        ""
    }

    // =====================================================================
    //  Alarm / reminder / calendar
    // =====================================================================
    private fun setAlarm(cmd: Cmd): Reply {
        val h = cmd.a["hour"]?.toIntOrNull() ?: return Reply("Koto tay alarm?")
        val m = cmd.a["minute"]?.toIntOrNull() ?: 0
        val ok = launch(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Aria")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        val whenText = cmd.a["millis"]?.toLongOrNull()?.let { fmtTime(it) } ?: String.format(Locale.US, "%d:%02d", h, m)
        return if (ok) Reply("Alarm set ✓ $whenText") else Reply("Clock app paini.")
    }

    private fun setReminder(cmd: Cmd): Reply {
        val millis = cmd.a["millis"]?.toLongOrNull() ?: return Reply("Kokhon mone koriye dibo?")
        val text = cmd.a["text"] ?: "Reminder"
        val id = (millis % Int.MAX_VALUE).toInt()
        val pi = PendingIntent.getBroadcast(
            ctx, id,
            Intent(ctx, ReminderReceiver::class.java).putExtra("text", text),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = ctx.getSystemService(AlarmManager::class.java)
        var note = ""
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            note = "\n(Thik shomoy chaile Settings → Exact alarms allow koro)"
        }
        return Reply("Reminder set ✓ ${fmtTime(millis)}\n\"$text\"$note")
    }

    private fun addEvent(cmd: Cmd): Reply {
        val millis = cmd.a["millis"]?.toLongOrNull() ?: return Reply("Kokhon?")
        val title = cmd.a["title"] ?: "Event"
        val ok = launch(
            Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, millis)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, millis + 3_600_000L)
        )
        return if (ok) Reply("Calendar-e \"$title\" ready (${fmtTime(millis)}). Save chepe dao ✓") else Reply("Calendar app paini.")
    }

    // =====================================================================
    //  Device controls
    // =====================================================================
    private fun torch(on: Boolean): Reply {
        return try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = torchId ?: cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }?.also { torchId = it } ?: return Reply("Ei phone e flashlight paini.")
            cm.setTorchMode(id, on)
            Reply(if (on) "Torch on ✓" else "Torch off ✓")
        } catch (e: Exception) {
            Reply("Torch jalate parlam na: ${e.message}")
        }
    }

    private fun volume(cmd: Cmd): Reply {
        val am = ctx.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val n = (cmd.a["n"]?.toIntOrNull() ?: 50).coerceIn(0, 100)
        val target = when (cmd.a["mode"]) {
            "set" -> n * max / 100
            "up" -> cur + maxOf(1, max / 5)
            "down" -> cur - maxOf(1, max / 5)
            "mute" -> 0
            else -> cur
        }.coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return Reply("Volume ${target * 100 / max}% ✓")
    }

    private fun brightness(cmd: Cmd): Reply {
        if (!Settings.System.canWrite(ctx)) {
            launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return Reply("Brightness bodlate 'Modify system settings' allow koro, tarpor abar bolo.")
        }
        val cr = ctx.contentResolver
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val n = cmd.a["n"]?.toIntOrNull()
        val target = when {
            n != null -> n.coerceIn(0, 100) * 255 / 100
            cmd.a["mode"] == "down" -> cur - 51
            else -> cur + 51
        }.coerceIn(5, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, target)
        return Reply("Brightness ${target * 100 / 255}% ✓")
    }

    private fun dnd(on: Boolean): Reply {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return Reply("Do Not Disturb access allow koro (Aria on kore), tarpor abar bolo.")
        }
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return Reply(if (on) "Silent (DND) mode on ✓" else "Silent mode off ✓")
    }

    // =====================================================================
    //  Info: notifications, missed calls, location, expenses
    // =====================================================================
    private fun readNotifications(): Reply {
        if (!NotifListener.enabled(ctx)) {
            launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return Reply("Notification porhar jonno 'Notification access' e Aria on koro, tarpor abar bolo.")
        }
        val list = NotifListener.items.take(6)
        if (list.isEmpty()) return Reply("Kono notun notification nai.")
        return Reply(list.mapIndexed { i, n ->
            "${i + 1}. ${n.app}" + (if (n.title.isNotEmpty()) " — ${n.title}" else "") + (if (n.text.isNotEmpty()) ": ${n.text}" else "")
        }.joinToString("\n"))
    }

    private suspend fun missedCalls(): Reply {
        if (!has(Manifest.permission.READ_CALL_LOG)) return needPerm("Call log")
        val rows = withContext(Dispatchers.IO) {
            val out = mutableListOf<String>()
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE),
                "${CallLog.Calls.TYPE}=?",
                arrayOf(CallLog.Calls.MISSED_TYPE.toString()),
                "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                val f = SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH)
                while (c.moveToNext() && out.size < 5) {
                    val who = c.getString(1)?.takeIf { it.isNotBlank() } ?: c.getString(0) ?: "Unknown"
                    out.add("$who — ${f.format(Date(c.getLong(2)))}")
                }
            }
            out
        }
        if (rows.isEmpty()) return Reply("Kono missed call nai 🎉")
        return Reply("Missed call:\n" + rows.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n"))
    }

    private fun location(share: Boolean): Reply {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) return needPerm("Location")
        val lm = ctx.getSystemService(LocationManager::class.java)
        val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }
            .maxByOrNull { it.time }
            ?: return Reply("Location paini. Maps app ekbar khule abar try koro.")
        val link = "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
        if (share) {
            launch(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Ami ekhane: $link"),
                    "Location share"
                )
            )
        }
        return Reply("Tomar location:\n$link")
    }

    private fun startOfDay(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun startOfMonth(): Long = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun expensesSince(t: Long): Double = store.expenses().filter { it.time >= t }.sumOf { it.amount }

    private fun expenseReport(): Reply {
        val all = store.expenses()
        if (all.isEmpty()) return Reply("Ekhono kono khoroch jog hoy ni. Jemon bolo: 500 taka bazar")
        val last = all.take(5).joinToString("\n") { "• ${money(it.amount)} taka — ${it.label}" }
        return Reply(
            "Ajker khoroch: ${money(expensesSince(startOfDay()))} taka\n" +
                "Ei mashe: ${money(expensesSince(startOfMonth()))} taka\n\nShesh khoroch:\n$last"
        )
    }

    // =====================================================================
    //  Routines
    // =====================================================================
    private suspend fun runRoutine(name: String): Reply {
        val cmds = store.routines()[name]
            ?: return Reply("'$name' naam e routine nai.\nBanate: routine save $name: torch on; alarm 7:00 am")
        val out = StringBuilder()
        for (c in cmds.split(";")) {
            val s = c.trim()
            if (s.isEmpty()) continue
            val cc = CommandParser.parse(s) ?: continue
            if (cc.type in setOf("routine_run", "yes", "no", "choose")) continue
            val r = execute(cc)
            out.append("• ").append(r.text.lines().first()).append("\n")
        }
        return Reply("Routine '$name' chollo:\n$out".trim())
    }

    // =====================================================================
    //  Claude AI: text tools + smart intent understanding
    // =====================================================================
    private suspend fun aiText(cmd: Cmd): Reply {
        val key = store.apiKey
        if (key.isBlank()) return Reply("Eta korte Claude API key lagbe. Settings → Claude API key e boshao.")
        var text = cmd.a["text"].orEmpty()
        if (text.isBlank()) text = readClipboard()
        if (text.isBlank()) return Reply("Kon text? Likho (jemon: translate: ...) ba age copy kore nao.")
        val sys = when (cmd.type) {
            "translate" -> "Translate the user's text. If it is Bangla, translate to English; otherwise translate to Bangla. Output only the translation."
            "summary" -> "Summarize the user's text briefly in the same language, in at most 5 short bullet points."
            else -> "Write a short, natural reply to the message the user gives you. Match its language (Bangla, Banglish or English) and tone. Output only the reply text."
        }
        return try {
            val out = ClaudeClient.ask(key, sys, text)
            copyToClipboard(out)
            Reply(out + "\n\n(Clipboard-e copy kora hoyeche)")
        } catch (e: Exception) {
            Reply(e.message ?: "AI error")
        }
    }

    private fun intentPrompt(): String {
        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm EEEE", Locale.US).format(Date())
        return """You convert a user's phone-assistant request (Bangla, Banglish or English) into ONE JSON object. Output ONLY the JSON, no markdown.
Current local time: $now
Format: {"type": "<type>", "args": {"key": "value"}}  (all arg values are strings)
Types and their args:
call{name}; number{name}; open{app}; alarm{when}; reminder{text,when}; timer{seconds}; stopwatch{action: start|stop};
sms{name,body}; whatsapp{name,body}; torch{on: true|false}; wifi; bluetooth; volume{mode: up|down|set|mute, n};
brightness{mode: up|down, n}; dnd{on: true|false}; notifs; missed; event{title,when}; translate{text}; summary{text};
draft{text}; note{text}; notes_show; notes_copy{n}; copy{text}; expense{amount,label}; expense_report; location{share: true|false}; chat{answer}
"when" is a local ISO time like 2026-11-12T07:00.
If the request is not a phone command, use type chat and put a short, helpful answer (same language as the user) in args.answer."""
    }

    private suspend fun aiIntent(text: String): Cmd? {
        val out = try {
            ClaudeClient.ask(store.apiKey, intentPrompt(), text, 500)
        } catch (e: Exception) {
            return Cmd("error", mapOf("msg" to (e.message ?: "AI error")))
        }
        val json = out.substring(out.indexOf('{').coerceAtLeast(0), out.lastIndexOf('}') + 1)
        return try {
            val o = JSONObject(json)
            val args = o.optJSONObject("args")
            val map = mutableMapOf<String, String>()
            args?.keys()?.forEach { k -> map[k] = args.optString(k) }
            normalizeAi(Cmd(o.getString("type"), map))
        } catch (e: Exception) {
            null
        }
    }

    private fun normalizeAi(c: Cmd): Cmd {
        val w = c.a["when"] ?: return c
        val ms = (try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(w.take(16))?.time
        } catch (e: Exception) {
            null
        }) ?: return c
        val cal = Calendar.getInstance().apply { timeInMillis = ms }
        return Cmd(
            c.type,
            c.a + mapOf(
                "millis" to ms.toString(),
                "hour" to cal.get(Calendar.HOUR_OF_DAY).toString(),
                "minute" to cal.get(Calendar.MINUTE).toString()
            )
        )
    }

    // =====================================================================
    //  Helpers
    // =====================================================================
    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun launch(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    private fun needPerm(name: String) =
        Reply("$name permission lagbe. Aria Settings → \"Sob permission dao\" chepe allow koro.")

    private fun fmtTime(ms: Long): String = SimpleDateFormat("EEE d MMM, h:mm a", Locale.ENGLISH).format(Date(ms))

    private fun money(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else String.format(Locale.US, "%.2f", v)

    private fun durationText(totalSec: Int): String {
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return buildList {
            if (h > 0) add("$h ghonta")
            if (m > 0) add("$m minute")
            if (s > 0 || isEmpty()) add("$s second")
        }.joinToString(" ")
    }
}
