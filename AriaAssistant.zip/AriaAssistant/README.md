# Aria — Personal Android Assistant

Premium Dark + Gold assistant app (Kotlin, Jetpack Compose, Material 3).
Bangla / Banglish / English text or voice commands, floating mic over every app.

## Build (APK banano)

1. Install **Android Studio** (latest) on a PC/laptop.
2. `File → Open` → select the `AriaAssistant` folder. Let Gradle sync finish (needs internet).
3. Connect your phone (USB debugging on) or start an emulator → press **Run ▶**.
   Or: `Build → Build Bundle(s) / APK(s) → Build APK(s)` and install the APK on the phone.

## First-time setup inside the app

Open the app → ⚙ Settings:

1. **Sob permission dao** → allow everything.
2. **Notification access**, **Do Not Disturb access**, **Modify system settings**, **Exact alarms** → turn Aria on in each.
3. **Floating mic** → allow "Display over other apps", come back, switch it on.
4. (Optional but recommended) paste your **Claude API key** so Aria understands free-form sentences and can translate / summarize / draft replies.

## Features (20)

| # | Feature | Example command |
|---|---------|-----------------|
| 1 | Contact → number | `Rahim er number ber koro` (also copies to clipboard) |
| 2 | Call (asks confirmation) | `Rahim ke call koro` → *Ha* |
| 3 | Open any app | `whatsapp open koro` |
| 4 | Copy notes to Gboard clipboard, one by one | `prothom 5 ta note copy koro` |
| 5 | Alarm | `alarm 7:00 am`, `kal shokal 6 tay alarm` |
| 6 | Reminder | `10 minute por pani khete mone koriye dio` |
| 7 | SMS (confirm) / WhatsApp (opens ready message) | `Rahim ke likho ami aschi`, `sms Rahim ke ...` |
| 8 | Torch, WiFi, Bluetooth, volume, brightness | `torch on`, `volume 60`, `brightness up` |
| 9 | Silent / DND | `silent mode on` |
| 10 | Timer, stopwatch | `timer 5 minute`, `stopwatch start` |
| 11 | Read notifications aloud | `notification porho` |
| 12 | Missed calls | `missed call dekhao` |
| 13 | Calendar event | `shukrobar 5 tay meeting` |
| 14 | Translate (Bangla ↔ English) | `translate: ...` (or copy text first, then say `translate`) |
| 15 | Summary | `summary: <long text>` |
| 16 | Reply draft | `reply: <message>` |
| 17 | Quick note | `note: kal bank jabo` |
| 18 | Expenses | `500 taka bazar`, `ajker khoroch koto` |
| 19 | Location / share | `ami kothay`, `location share koro` |
| 20 | Custom routines | `routine save morning: torch on; alarm 7:00 am` → `routine morning` |

Calls and SMS **always ask Ha/Na first**. If two contacts match a name, Aria shows a numbered list.

## Honest limits

* **WiFi / Bluetooth**: Android 10+ does not let any normal app switch them on/off directly. Aria opens the quick panel (one tap).
* **Reading notes from other note apps** is not done (fragile). Aria copies notes saved *inside Aria* (`note: ...`). Gboard clipboard keeps a copied item for ~1 hour unless you pin it.
* **Contact names** must match how they are saved (Banglish name vs Bangla-script name won't match).
* WhatsApp number format assumes Bangladesh (`01XXXXXXXXX` → `8801XXXXXXXXX`).
* Reminders are lost if the phone reboots. Alarms/timers (system Clock app) are not.
* AI features need internet and use your Claude API key (small cost per request). Model is set in `core/ClaudeClient.kt` (`MODEL`).
* Floating mic must be switched on again if you force-stop the app.

## Customize

* App name: `app/src/main/res/values/strings.xml`
* Colors: `ui/theme/Theme.kt` (Gold, GoldLight, GoldDark, Black…) and `res/values/colors.xml`
* App icon: `res/drawable/ic_launcher_foreground.xml`
* Add a new command: parse it in `core/CommandParser.kt`, run it in `core/Assistant.kt` (`execute`).

## GitHub diye APK banano (laptop/Android Studio chhara)

1. GitHub-e notun repository banao, `AriaAssistant` folder-er shob file (`.github` folder shoho) upload koro.
2. Repo-r **Actions** tab e jao, **Build APK** workflow chalo hobe (ba **Run workflow** chapo).
3. 4-6 minute pore build sesh hole oi run khule niche **Artifacts → Aria-APK** download koro.
4. Zip extract kore `app-debug.apk` phone-e install koro (Unknown sources allow korte hobe).
